import math

def pole_kola(r):
    """Oblicz pole koła"""
    return math.pi * r ** 2

def obwod_kola(r):
    """Oblicz obwód koła"""
    return 2 * math.pi * r
