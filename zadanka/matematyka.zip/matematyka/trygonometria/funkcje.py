import math

def sinus(kat_w_stopniach):

    kat_w_radianach = math.radians(kat_w_stopniach)
    return math.sin(kat_w_radianach)

def cosinus(kat_w_stopniach):

    kat_w_radianach = math.radians(kat_w_stopniach)
    return math.cos(kat_w_radianach)
