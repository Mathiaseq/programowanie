from matematyka.geometria.figura import pole_kola, obwod_kola
from matematyka.trygonometria.funkcje import sinus, cosinus


print("GEOMETRIA")
promien = 5
print(f"koła promien {promien}:")
print(f"Pole koła: {pole_kola(promien)}")
print(f"Obwód koła: {obwod_kola(promien)}")


print("\nTRYGONOMETRIA")
kat = 45
print(f"Dla kąta {kat}:")
print(f"sin({kat}) = {sinus(kat)}")
print(f"cos({kat}) = {cosinus(kat)}")

